/*****************************************************************************
 * QTFairUse: QuickTime AAC memory dumper
 * Copyright (C) 2003 Jon Lech Johansen
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <tchar.h>
#include <windows.h>

#define DLLNAME "November.dll"

UCHAR p1[] =
{
    0xE9, 0xEA, 0xDB, 0x01, 0x00, 0x90, 0x90,
    0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90
};

UCHAR p2[] =
{
    0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90,
    0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90,
    0x90, 0x8B, 0x5C, 0x24, 0x0C, 0x81, 0xFB,
    0x00, 0x24, 0x00, 0x00, 0x8B, 0xC1, 0x0F,
    0x87, 0x0D, 0x24, 0xFE, 0xFF, 0x8B, 0x4C,
    0x24, 0x08, 0x8B, 0x11, 0x60, 0x52, 0x53,
    0x68, 0xD4, 0xE5, 0x3B, 0x67, 0xFF, 0x15,
    0x8C, 0x70, 0x3B, 0x67, 0x85, 0xC0, 0x75,
    0x0F, 0x68, 0xD4, 0xE5, 0x3B, 0x67, 0xFF,
    0x15, 0xB8, 0x70, 0x3B, 0x67, 0x85, 0xC0,
    0x74, 0x18, 0x68, 0x6C, 0xE6, 0x3B, 0x67,
    0x50, 0xFF, 0x15, 0x88, 0x70, 0x3B, 0x67,
    0x85, 0xC0, 0x74, 0x08, 0xFF, 0xD0, 0x61,
    0xE9, 0xD4, 0x23, 0xFE, 0xFF, 0x5B, 0x5A,
    0x61, 0xE9, 0xCC, 0x23, 0xFE, 0xFF, 0x90,
    0x90, 0x90, 0x90, 0x90, 0x90, 0x90
};

int main( int argc, char *argv[] )
{
    WORD wTmp;
    HANDLE hFile;
    DWORD dwDummy;
    TCHAR szPath[MAX_PATH+1];
    TCHAR szWindows[MAX_PATH+1];
    TCHAR *szDLL = _T("system32\\" DLLNAME);

    _ftprintf( stdout, 
               _T("QTFairUse: Copyright (C) 2003 Jon Lech Johansen\n") );

    if( !GetWindowsDirectory( szWindows, MAX_PATH+1 ) )
    {
        _ftprintf( stderr, _T("GetWindowsDirectory failed (0x%08lX)\n"),
                   GetLastError() );
        return( 1 );
    } 

    _sntprintf( szPath, MAX_PATH, "%s\\%s", szWindows, szDLL );

    _ftprintf( stdout, _T("Copying %s -> %s\n"), _T(DLLNAME), szPath ); 

    if( !CopyFile( _T(DLLNAME), szPath, FALSE ) )
    {
        _ftprintf( stderr, _T("CopyFile failed (0x%08lX)\n"),
                   GetLastError() );
        return( 1 );
    }

    _sntprintf( szPath, MAX_PATH, 
                "%s\\system32\\QuickTime\\QuickTimeMPEG4.qtx", szWindows );

    _ftprintf( stdout, _T("Patching %s\n"), szPath );

    hFile = CreateFile( szPath, GENERIC_READ | GENERIC_WRITE, 0, NULL,
                        OPEN_EXISTING, 0, NULL );
    if( hFile == INVALID_HANDLE_VALUE )
    {
        _ftprintf( stderr, _T("CreateFile failed (0x%08lX)\n"),
                   GetLastError() );
        return( 1 );
    }                        

#define PATCH( offset, check, p ) \
    if( SetFilePointer( hFile, offset, NULL, FILE_BEGIN ) == \
        INVALID_SET_FILE_POINTER ) \
    { \
        _ftprintf( stderr, _T("SetFilePointer failed (0x%08lX)\n"), \
                   GetLastError() ); \
        CloseHandle( hFile ); \
        return( 1 ); \
    } \
\
    if( !ReadFile( hFile, &wTmp, sizeof(wTmp), &dwDummy, NULL ) ) \
    { \
        _ftprintf( stderr, _T("ReadFile failed (0x%08lX)\n"), \
                   GetLastError() ); \
        CloseHandle( hFile ); \
        return( 1 ); \
    } \
\
    if( wTmp == check ) \
    { \
        if( SetFilePointer( hFile, offset, NULL, FILE_BEGIN ) == \
            INVALID_SET_FILE_POINTER ) \
        { \
            _ftprintf( stderr, _T("SetFilePointer failed (0x%08lX)\n"), \
                       GetLastError() ); \
            CloseHandle( hFile ); \
            return( 1 ); \
        } \
\
        if( !WriteFile( hFile, p, sizeof(p)/sizeof(p[0]), \
                        &dwDummy, NULL ) ) \
        { \
            _ftprintf( stderr, _T("WriteFile failed (0x%08lX)\n"), \
                       GetLastError() ); \
            CloseHandle( hFile ); \
            return( 1 ); \
        } \
    } \
    else \
    { \
        if( wTmp == ((p[1] << 8) | p[0]) ) \
        { \
            _ftprintf( stdout, _T("Offset 0x%08X already patched.\n"), \
                       offset ); \
        } \
        else \
        { \
            _ftprintf( stderr, _T("Offset [0x%08X] = 0x%04X, not 0x%04X"), \
                       offset, wTmp, check ); \
            CloseHandle( hFile ); \
            return( 1 ); \
        } \
    }

    PATCH( 0x028631, 0x5C8B, p1 ); 
    PATCH( 0x046211, 0x0000, p2 );

    CloseHandle( hFile );

    _ftprintf( stdout, _T("Success! Fair Use enabled.") );

    return( 0 );
}
