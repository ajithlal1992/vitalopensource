/*****************************************************************************
 * QTFairUse: QuickTime AAC memory dumper
 * Copyright (C) 2003 Jon Lech Johansen
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <tchar.h>
#include <windows.h>
#include <shlobj.h>

#define DUMPFILE "QTFairUse.aac"

HANDLE hFile = INVALID_HANDLE_VALUE;

BOOL WINAPI DllMain( HANDLE hDll, DWORD dwReason, LPVOID lpReserved )
{
    switch( dwReason )
    {
        case DLL_PROCESS_ATTACH:
        {
            if( hFile == INVALID_HANDLE_VALUE )
            {
                TCHAR szPath[MAX_PATH];
                TCHAR *szFileName = _T("\\" DUMPFILE);

                if( FAILED( SHGetFolderPath( NULL, CSIDL_DESKTOP,
                                             NULL, 0, szPath ) ) )
                {
                    _tcsncpy( szPath, _T("C:"), MAX_PATH-1 );
                }

                _tcsncat( szPath, szFileName,
                          min( _tcslen( szFileName ),
                               (MAX_PATH-1) - _tcslen( szPath ) ) ); 

                hFile = CreateFile( szPath,
                                    GENERIC_WRITE, 0, NULL, 
                                    CREATE_ALWAYS, 0, NULL );
            }
        }
        break;

        case DLL_PROCESS_DETACH:
        {
            if( hFile != INVALID_HANDLE_VALUE )
            {
                CloseHandle( hFile );
                hFile = INVALID_HANDLE_VALUE;
            }
        }
        break;
    }

    return( TRUE );
}

VOID WINAPI Friday( DWORD dwSize, PUCHAR pBuffer )
{
    DWORD dwDummy;

    if( hFile != INVALID_HANDLE_VALUE )
    {
        WriteFile( hFile, pBuffer, dwSize, &dwDummy, NULL );
    }
}
